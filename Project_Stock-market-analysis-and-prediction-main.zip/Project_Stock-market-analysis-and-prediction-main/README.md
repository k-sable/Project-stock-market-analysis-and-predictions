# Project_Stock-market-analysis-and-prediction

This project is about to predict the future 5 days closing price of stock market. 

Data collected from Yahoo Finance - https://finance.yahoo.com/quote/%5ENSEI/history/?guccounter=1&guce_referrer=aHR0cHM6Ly93d3cuZ29vZ2xlLmNvbS8&guce_referrer_sig=AQAAAIZts_nie0ZyLf4Cpk71SiUNUl4aIqVHFRbtNI5vKpEsimrHnRFDVR6m7vGlUmBBusUKcKcRrkDwjjmcwVwoC4pMNfxswFy772Ih48RRPk3izoCTR-n5l4jmTmZiB_k_9byhHfA_RrPpQNwi4ODFMGvJm_FC4tdlL7xD0a9IcSKh
