"""
Routes and views for the flask application.
"""

from datetime import datetime
from flask import render_template
from FlaskWebProject2 import app

@app.route('/')
@app.route('/About_Stock_Market')
def About_Stock_Market():
    """Renders the about page."""
    return render_template(
        'About_Stock_Market.html',
        title='Stock Market Analysis',
        year=datetime.now().year,

    )
@app.route('/ML_Prediction')
def ML_Prediction():
    """Renders the home page."""
    return render_template(
        'ML_Prediction.html',
        title='Stock Market Prediction',
        year=datetime.now().year,
    )

@app.route('/Stock_Analysis')
def Stock_Analysis():
    """Renders the contact page."""
    return render_template(
        'Stock_Analysis.html',
        title='Stock Market Analysis',
        year=datetime.now().year,
    )

@app.route('/Stock_Analysis_Deep')
def Stock_Analysis_Deep():
    """Renders the about page."""
    return render_template(
        'Stock_Analysis_Deep.html',
        title='Stock Market Analysis',
        year=datetime.now().year,
    )

